<?php
$displayname = "Savant - Forsaken";
$artists = "1, 2";
$releaseyear = "20XX";
$imglink = "https://f4.bcbits.com/img/a0802373014_2.jpg";
$vidlink = "aN_ZCMOx0lo";
$radiolink = "./radio.php?item=forsaken";
$downlink = "some mega link or whatever";
$mirrorlink = "mega link number 2";
$tags = "Savant, Vex, 2016LUL, Artist2";
?>