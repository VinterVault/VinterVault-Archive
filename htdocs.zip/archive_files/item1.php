<?php
$displayname = "Savant - Vex";
$artists = "1, 2";
$releaseyear = "20XX";
$imglink = "https://cdn.discordapp.com/attachments/234386053769854977/310899949204144128/0009096492_41.png";
$vidlink = "-X2SzFjT2Hs";
$radiolink = "./radio.php?item=item1";
$downlink = "some mega link or whatever";
$mirrorlink = "mega link number 2";
$tags = "Savant, Vex, 2016LUL, Artist2";
?>