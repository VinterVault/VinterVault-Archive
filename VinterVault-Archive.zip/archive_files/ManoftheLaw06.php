<?php
$displayname = "Aleksander Vinter - Man Of The Law [2006]";
$artists = "Aleksander Vinter";
$releaseyear = "2006";
$imglink = "https://i.ytimg.com/vi/MqKNOL6QdEw/0.jpg";
$vidlink = "MqKNOL6QdEw";
$radiolink = "./radio.php?item=ManoftheLaw06";
$downlink = "some mega link or whatever";
$mirrorlink = "mega link number 2";
$tags = "Savant, Vex, 2016LUL, Artist2";
?>