<?php
$displayname = "SSavant - Vex qwertyuiop asdfghjkl zxcvbnm qwertyuiop asdfghjkl zxcvbnm 12345678901234567890";
$artists = "1, 2";
$releaseyear = "20XX";
$imglink = "https://cdn.discordapp.com/attachments/234386053769854977/310899949204144128/0009096492_41.png";
$vidlink = "-X2SzFjT2Hs";
$radiolink = "./radio.php?item=Template";
$downlink = "some mega link or whatever";
$mirrorlink = "mega link number 2";
$tags = "Savant, Vex, 2016LUL, Artist2";
?>